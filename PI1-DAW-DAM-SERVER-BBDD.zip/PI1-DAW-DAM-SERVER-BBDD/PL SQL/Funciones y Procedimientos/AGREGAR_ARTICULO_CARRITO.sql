--------------------------------------------------------
--  DDL for Procedure AGREGAR_ARTICULO_CARRITO
--------------------------------------------------------
set define off;

  CREATE OR REPLACE EDITIONABLE PROCEDURE "C##1DAMSANTAMARIA"."AGREGAR_ARTICULO_CARRITO" (
    p_id_usuario IN VARCHAR2,
    p_id_contenido IN NUMBER
) IS
    v_lineaID NUMBER;
    v_carroID NUMBER;
    v_facturaID NUMBER;
BEGIN
    -- Obtener el ID del carro de compra del usuario
    SELECT ID INTO v_carroID
    FROM Carro_Compra
    WHERE ID_USUARIO = p_id_usuario;

    -- Obtener el ID de la factura preexistente del usuario
    SELECT NUMERO INTO v_facturaID
    FROM Factura
    WHERE ID_USUARIO = p_id_usuario AND IMP_BASE = 0 AND IMP_IVA = 0;

    -- Insertar una nueva línea de factura
    INSERT INTO Linea_Factura (ID, ID_CARRO, NUM_FACTURA)
    VALUES (SEQ_LINEAID.NEXTVAL, v_carroID, v_facturaID)
    RETURNING ID INTO v_lineaID;
    
    -- Insertar el artículo a facturar
    INSERT INTO Articulos_Facturar (ID_LINEA, ID_CONTENIDO)
    VALUES (v_lineaID, p_id_contenido);
    
    UPDATE CARRO_COMPRA
    SET
        changedts = SYSDATE
    WHERE ID = v_carroID;
END;

/
