--------------------------------------------------------
--  DDL for Function ELIMINAR_LINEA
--------------------------------------------------------

  CREATE OR REPLACE EDITIONABLE FUNCTION "C##1DAMSANTAMARIA"."ELIMINAR_LINEA" (
    p_id_linea in linea_factura.id%TYPE
)RETURN NUMBER
IS
    v_filas_eliminadas NUMBER := 0;
BEGIN
    DELETE FROM articulos_facturar
    WHERE ID_LINEA = p_id_linea;

    DELETE FROM LINEA_FACTURA
    WHERE ID = p_id_linea;

    v_filas_eliminadas := v_filas_eliminadas + SQL%ROWCOUNT;
    RETURN v_filas_eliminadas;
END;

/
