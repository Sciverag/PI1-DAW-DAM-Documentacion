--------------------------------------------------------
--  DDL for Function ACTUALIZAR_PUNTUACION
--------------------------------------------------------

  CREATE OR REPLACE EDITIONABLE FUNCTION "C##1DAMSANTAMARIA"."ACTUALIZAR_PUNTUACION" (
    p_id IN  contenido.id%TYPE,
    p_tag_usuario in usuario.tag_usuario%TYPE,
    puntuacion_nueva IN contenido.punt_media%TYPE
)RETURN NUMBER
IS
    v_filas_actualizadas NUMBER := 0;
BEGIN
    UPDATE VALORA
    SET 
        PUNTOS = puntuacion_nueva
    WHERE id_contenido = p_id AND id_usuario = p_tag_usuario;
    
    UPDATE contenido
    SET punt_media = (
        SELECT AVG(PUNTOS)
        FROM valora
        WHERE id_contenido = p_id
    ),
    changedts = SYSDATE
    WHERE id = p_id;

    v_filas_actualizadas := SQL%ROWCOUNT;

    RETURN v_filas_actualizadas;
END;

/
