--------------------------------------------------------
--  DDL for Procedure ADMINISTRAR_CADUCIDAD
--------------------------------------------------------
set define off;

  CREATE OR REPLACE EDITIONABLE PROCEDURE "C##1DAMSANTAMARIA"."ADMINISTRAR_CADUCIDAD" (
    p_tag_usuario IN USUARIO.tag_usuario%TYPE,
    p_id IN contenido.id%TYPE
)IS
    v_alquilado NUMBER;
    v_fechaCaducidad DATE;
BEGIN
    SELECT COUNT(*) INTO v_alquilado FROM ALQUILA WHERE ID_USUARIO = p_tag_usuario AND ID_CONTENIDO = p_id;

    IF v_alquilado <> 0 THEN
    SELECT caduca into v_fechaCaducidad from ALQUILA WHERE ID_USUARIO = p_tag_usuario AND ID_CONTENIDO = p_id;
    IF v_fechaCaducidad <= SYSDATE THEN
    DELETE FROM ALQUILA WHERE ID_USUARIO = p_tag_usuario AND ID_CONTENIDO = p_id;
    END IF;
    END IF;
END;   

/
