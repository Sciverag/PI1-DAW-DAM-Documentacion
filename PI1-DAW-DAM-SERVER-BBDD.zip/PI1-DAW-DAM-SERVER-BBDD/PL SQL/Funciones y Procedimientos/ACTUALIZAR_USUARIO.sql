--------------------------------------------------------
--  DDL for Function ACTUALIZAR_USUARIO
--------------------------------------------------------

  CREATE OR REPLACE EDITIONABLE FUNCTION "C##1DAMSANTAMARIA"."ACTUALIZAR_USUARIO" (
    p_tag_usuario IN USUARIO.TAG_USUARIO%TYPE,
    p_contrasenya IN USUARIO.CONTRASENYA%TYPE DEFAULT NULL,
    p_domicilio IN USUARIO.DOMICILIO%TYPE DEFAULT NULL,
    p_cod_postal IN USUARIO.COD_POSTAL%TYPE DEFAULT NULL,
    p_email IN USUARIO.EMAIL%TYPE DEFAULT NULL,
    p_fech_nac IN USUARIO.FECH_NAC%TYPE DEFAULT NULL,
    p_nombre IN USUARIO.NOMBRE%TYPE DEFAULT NULL,
    p_apellidos IN USUARIO.APELLIDOS%TYPE DEFAULT NULL,
    p_num_tarjeta IN USUARIO.NUM_TARJETA%TYPE DEFAULT NULL
) RETURN NUMBER
IS
    v_filas_actualizadas NUMBER := 0;
BEGIN
    UPDATE USUARIO
    SET 
        CONTRASENYA = NVL(p_contrasenya, CONTRASENYA),
        DOMICILIO = NVL(p_domicilio, DOMICILIO),
        COD_POSTAL = NVL(p_cod_postal, COD_POSTAL),
        EMAIL = NVL(p_email, EMAIL),
        FECH_NAC = NVL(p_fech_nac, FECH_NAC),
        NOMBRE = NVL(p_nombre, NOMBRE),
        APELLIDOS = NVL(p_apellidos, APELLIDOS),
        NUM_TARJETA = NVL(p_num_tarjeta, NUM_TARJETA),
        changedts = SYSDATE
    WHERE TAG_USUARIO = p_tag_usuario;

    v_filas_actualizadas := SQL%ROWCOUNT;

    RETURN v_filas_actualizadas;
END;

/
