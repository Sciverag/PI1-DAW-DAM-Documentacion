--------------------------------------------------------
--  DDL for Procedure AÑADIR_PUNTUACION
--------------------------------------------------------
set define off;

  CREATE OR REPLACE EDITIONABLE PROCEDURE "C##1DAMSANTAMARIA"."AÑADIR_PUNTUACION" (
    p_id IN contenido.id%TYPE,
    p_tag_usuario IN usuario.tag_usuario%TYPE,
    p_puntuacion IN contenido.punt_media%TYPE
)
IS
BEGIN
    -- Insertar la nueva puntuación en la tabla VALORA
    INSERT INTO VALORA (ID_USUARIO, ID_CONTENIDO, PUNTOS)
    VALUES (p_tag_usuario, p_id, p_puntuacion);

    -- Actualizar la puntuación media del contenido en la tabla CONTENIDO
    UPDATE contenido
    SET punt_media = (
        SELECT AVG(PUNTOS)
        FROM valora
        WHERE id_contenido = p_id
    ),
    changedts = SYSDATE
    WHERE id = p_id;
END;

/
