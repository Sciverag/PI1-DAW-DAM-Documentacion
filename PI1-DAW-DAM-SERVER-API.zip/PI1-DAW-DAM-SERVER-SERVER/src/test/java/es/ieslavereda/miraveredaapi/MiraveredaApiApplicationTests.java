package es.ieslavereda.miraveredaapi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MiraveredaApiApplicationTests {

    @Test
    void contextLoads() {
    }

}
