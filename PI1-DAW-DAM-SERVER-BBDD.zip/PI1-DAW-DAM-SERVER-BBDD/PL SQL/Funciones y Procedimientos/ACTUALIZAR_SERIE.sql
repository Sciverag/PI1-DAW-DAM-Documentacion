--------------------------------------------------------
--  DDL for Function ACTUALIZAR_SERIE
--------------------------------------------------------

  CREATE OR REPLACE EDITIONABLE FUNCTION "C##1DAMSANTAMARIA"."ACTUALIZAR_SERIE" (
    p_id IN SERIE.ID%TYPE,
    p_disponibilidad IN serie.disponibilidad%TYPE DEFAULT NULL,
    p_titulo in serie.titulo%TYPE DEFAULT NULL,
    p_descripcion IN serie.descripcion%TYPE DEFAULT NULL,
    p_url_imagen IN serie.url_imagen% TYPE DEFAULT NULL
) RETURN NUMBER
IS
    v_filas_actualizadas NUMBER := 0;
BEGIN
    -- Actualizar tabla SERIE
    UPDATE SERIE
    SET 
        DISPONIBILIDAD = NVL(p_disponibilidad, DISPONIBILIDAD),
        DESCRIPCION = NVL(p_descripcion, DESCRIPCION),
        TITULO = NVL(p_titulo,TITULO),
        URL_IMAGEN = NVL(p_url_imagen,URL_IMAGEN)
    WHERE ID = p_id;

    v_filas_actualizadas := v_filas_actualizadas + SQL%ROWCOUNT;

    RETURN v_filas_actualizadas;
END;

/
