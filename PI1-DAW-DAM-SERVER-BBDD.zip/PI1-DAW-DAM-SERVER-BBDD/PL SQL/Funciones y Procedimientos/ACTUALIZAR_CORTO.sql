--------------------------------------------------------
--  DDL for Function ACTUALIZAR_CORTO
--------------------------------------------------------

  CREATE OR REPLACE EDITIONABLE FUNCTION "C##1DAMSANTAMARIA"."ACTUALIZAR_CORTO" (
    p_id_cont IN CORTO.ID_CONT%TYPE,
    -- Campos comunes
    p_titulo IN CONTENIDO.TITULO%TYPE DEFAULT NULL,
    p_descripcion IN CONTENIDO.DESCRIPCION%TYPE DEFAULT NULL,
    p_url_imagen IN CONTENIDO.URL_IMAGEN%TYPE DEFAULT NULL,
    p_actores IN CONTENIDO.ACTORES%TYPE DEFAULT NULL,
    p_punt_media IN CONTENIDO.PUNT_MEDIA%TYPE DEFAULT NULL,
    p_fech_estreno IN CONTENIDO.FECH_ESTRENO%TYPE DEFAULT NULL,
    p_duracion IN CONTENIDO.DURACION%TYPE DEFAULT NULL,
    p_director IN CONTENIDO.DIRECTOR%TYPE DEFAULT NULL,
    p_id_genero IN CONTENIDO.ID_GENERO%TYPE DEFAULT NULL,
    p_id_tarifa IN CONTENIDO.ID_TARIFA%TYPE DEFAULT NULL
) RETURN NUMBER
IS
    v_filas_actualizadas NUMBER := 0;
BEGIN
    -- Llamar a la función general
    v_filas_actualizadas := actualizar_contenido(
        p_id => p_id_cont,
        p_titulo => p_titulo,
        p_descripcion => p_descripcion,
        p_url_imagen => p_url_imagen,
        p_actores => p_actores,
        p_punt_media => p_punt_media,
        p_fech_estreno => p_fech_estreno,
        p_duracion => p_duracion,
        p_director => p_director,
        p_id_genero => p_id_genero,
        p_id_tarifa => p_id_tarifa
    );

    RETURN v_filas_actualizadas;
END;

/
