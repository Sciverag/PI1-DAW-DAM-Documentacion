--------------------------------------------------------
--  DDL for Procedure CREAR_SERIE
--------------------------------------------------------
set define off;

  CREATE OR REPLACE EDITIONABLE PROCEDURE "C##1DAMSANTAMARIA"."CREAR_SERIE" (
    p_titulo IN VARCHAR2,
    p_descripcion IN VARCHAR2,
    p_disponibilidad IN DATE DEFAULT NULL,
    p_url_imagen IN VARCHAR2 DEFAULT NULL
) IS
BEGIN
    -- Insertar en la tabla Serie
    INSERT INTO Serie (
        ID, DISPONIBILIDAD, TITULO, DESCRIPCION, URL_IMAGEN
    ) VALUES (
        SEQ_SERIE.nextval, p_disponibilidad, p_titulo, p_descripcion,p_url_imagen
    );
END;

/
