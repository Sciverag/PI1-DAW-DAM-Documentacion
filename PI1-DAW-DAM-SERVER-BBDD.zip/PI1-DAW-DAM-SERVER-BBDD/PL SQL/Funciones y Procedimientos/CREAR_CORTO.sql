--------------------------------------------------------
--  DDL for Procedure CREAR_CORTO
--------------------------------------------------------
set define off;

  CREATE OR REPLACE EDITIONABLE PROCEDURE "C##1DAMSANTAMARIA"."CREAR_CORTO" (
    p_titulo IN VARCHAR2,
    p_descripcion IN VARCHAR2,
    p_url_imagen IN VARCHAR2 DEFAULT NULL,
    p_actores IN VARCHAR2 DEFAULT NULL,
    p_punt_media IN FLOAT DEFAULT NULL,
    p_fech_estreno IN DATE DEFAULT NULL,
    p_duracion IN FLOAT DEFAULT NULL,
    p_director IN VARCHAR2,
    p_id_genero IN NUMBER,
    p_id_tarifa IN NUMBER
) IS
BEGIN
    -- Insertar en la tabla Contenido
    INSERT INTO Contenido (
        ID, TITULO, DESCRIPCION, URL_IMAGEN, ACTORES, PUNT_MEDIA, FECH_ESTRENO, DURACION, DIRECTOR, ID_GENERO, ID_TARIFA
    ) VALUES (
        SEQ_IDCONTENIDO.nextval, p_titulo, p_descripcion, p_url_imagen, p_actores, p_punt_media, p_fech_estreno, p_duracion, p_director, p_id_genero, p_id_tarifa
    );

    INSERT INTO Corto (
        ID_CONT
    ) VALUES (
        SEQ_IDCONTENIDO.currval
    );
END;

/
