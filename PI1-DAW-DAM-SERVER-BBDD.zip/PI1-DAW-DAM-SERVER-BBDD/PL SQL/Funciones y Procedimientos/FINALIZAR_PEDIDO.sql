--------------------------------------------------------
--  DDL for Procedure FINALIZAR_PEDIDO
--------------------------------------------------------
set define off;

  CREATE OR REPLACE EDITIONABLE PROCEDURE "C##1DAMSANTAMARIA"."FINALIZAR_PEDIDO" (
    p_id_usuario IN VARCHAR2
) IS
    v_facturaID NUMBER;
    v_importeBase NUMBER := 0;
    v_importeIVA NUMBER := 0;
    v_total NUMBER := 0;
    CONSTANTE_IVA CONSTANT NUMBER := 0.21;
    v_carroID NUMBER;
BEGIN
    -- Obtener el ID del carro de compra del usuario
    SELECT ID INTO v_carroID
    FROM Carro_Compra
    WHERE ID_USUARIO = p_id_usuario;

    -- Obtener el ID de la factura preexistente del usuario
    SELECT NUMERO INTO v_facturaID
    FROM Factura
    WHERE ID_USUARIO = p_id_usuario AND IMP_BASE = 0 AND IMP_IVA = 0;

    -- Calcular el importe base sumando los precios de los contenidos en el carrito
    FOR item IN (SELECT af.ID_CONTENIDO, t.Precio
                 FROM Articulos_Facturar af
                 JOIN Contenido c ON af.ID_CONTENIDO = c.ID
                 JOIN Tarifa t ON c.ID_Tarifa = t.ID
                 JOIN Linea_Factura lf ON af.ID_LINEA = lf.ID
                 WHERE lf.ID_CARRO = v_carroID) LOOP
        v_importeBase := v_importeBase + item.Precio;

        -- Insertar en Alquila
        INSERT INTO Alquila (ID_USUARIO, ID_CONTENIDO,CADUCA)
        VALUES (p_id_usuario, item.ID_CONTENIDO,SYSDATE + 7);
    END LOOP;

    -- Calcular importes con IVA
    v_importeIVA := v_importeBase * CONSTANTE_IVA;
    v_total := v_importeBase + v_importeIVA;

    -- Actualizar la factura con los importes calculados
    UPDATE Factura
    SET IMP_BASE = v_importeBase,
        IMP_IVA = v_importeIVA,
        CHANGEDTS = SYSDATE
    WHERE NUMERO = v_facturaID;
    


    -- Eliminar los artículos facturados asociados a las líneas de la factura en el carrito
    DELETE FROM Articulos_Facturar
    WHERE ID_LINEA IN (SELECT ID FROM Linea_Factura WHERE ID_CARRO = v_carroID);


    -- Eliminar las líneas de factura del carrito
    DELETE FROM Linea_Factura
    WHERE ID_CARRO = v_carroID;

    -- Crear una nueva factura vacía para el usuario para el siguiente pedido
    INSERT INTO Factura (NUMERO, FECHA, IMP_BASE, IMP_IVA, ID_USUARIO)
    VALUES (SEC_FACTURAID.NEXTVAL, SYSDATE, 0, 0, p_id_usuario);
    
END;

/
