--------------------------------------------------------
--  DDL for Function ELIMINAR_USUARIO
--------------------------------------------------------

  CREATE OR REPLACE EDITIONABLE FUNCTION "C##1DAMSANTAMARIA"."ELIMINAR_USUARIO" (p_tag_usuario IN usuario.tag_usuario%TYPE)
RETURN NUMBER
IS
    v_existe_usuario NUMBER := 0;
    v_filas_eliminadas NUMBER := 0;
BEGIN
    SELECT COUNT(*)
    INTO v_existe_usuario
    FROM usuario
    WHERE tag_usuario = p_tag_usuario;

    IF v_existe_usuario <> 1 THEN
        RAISE_APPLICATION_ERROR(-20001, 'Tag de usuario no encontrado');
    END IF;

    DELETE FROM usuario
    WHERE tag_usuario = p_tag_usuario;

    v_filas_eliminadas := SQL%ROWCOUNT;

    RETURN v_filas_eliminadas;
END;

/
