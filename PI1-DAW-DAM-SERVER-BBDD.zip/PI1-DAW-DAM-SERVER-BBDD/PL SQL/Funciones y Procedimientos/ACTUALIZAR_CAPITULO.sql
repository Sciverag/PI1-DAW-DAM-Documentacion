--------------------------------------------------------
--  DDL for Function ACTUALIZAR_CAPITULO
--------------------------------------------------------

  CREATE OR REPLACE EDITIONABLE FUNCTION "C##1DAMSANTAMARIA"."ACTUALIZAR_CAPITULO" (
    p_id_cont IN CAPITULO.ID_CONT%TYPE,
    p_temporada IN CAPITULO.TEMPORADA%TYPE DEFAULT NULL,
    p_id_serie IN CAPITULO.ID_SERIE%TYPE DEFAULT NULL,
    -- Campos comunes
    p_titulo IN CONTENIDO.TITULO%TYPE DEFAULT NULL,
    p_descripcion IN CONTENIDO.DESCRIPCION%TYPE DEFAULT NULL,
    p_url_imagen IN CONTENIDO.URL_IMAGEN%TYPE DEFAULT NULL,
    p_actores IN CONTENIDO.ACTORES%TYPE DEFAULT NULL,
    p_punt_media IN CONTENIDO.PUNT_MEDIA%TYPE DEFAULT NULL,
    p_fech_estreno IN CONTENIDO.FECH_ESTRENO%TYPE DEFAULT NULL,
    p_duracion IN CONTENIDO.DURACION%TYPE DEFAULT NULL,
    p_director IN CONTENIDO.DIRECTOR%TYPE DEFAULT NULL,
    p_id_genero IN CONTENIDO.ID_GENERO%TYPE DEFAULT NULL,
    p_id_tarifa IN CONTENIDO.ID_TARIFA%TYPE DEFAULT NULL
) RETURN NUMBER
IS
    v_filas_actualizadas NUMBER := 0;
BEGIN
    -- Llamar a la función general
    v_filas_actualizadas := actualizar_contenido(
        p_id => p_id_cont,
        p_titulo => p_titulo,
        p_descripcion => p_descripcion,
        p_url_imagen => p_url_imagen,
        p_actores => p_actores,
        p_punt_media => p_punt_media,
        p_fech_estreno => p_fech_estreno,
        p_duracion => p_duracion,
        p_director => p_director,
        p_id_genero => p_id_genero,
        p_id_tarifa => p_id_tarifa
    );

    -- Actualizar tabla CAPITULO
    UPDATE CAPITULO
    SET 
        TEMPORADA = NVL(p_temporada, TEMPORADA),
        ID_SERIE = NVL(p_id_serie, ID_SERIE)
    WHERE ID_CONT = p_id_cont;
    
    --Actualizar changetds tabla Contenido 
    v_filas_actualizadas := v_filas_actualizadas + SQL%ROWCOUNT;

    RETURN v_filas_actualizadas;
END;

/
