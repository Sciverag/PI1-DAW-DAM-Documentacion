--------------------------------------------------------
--  DDL for Sequence SEQ_IDCONTENIDO
--------------------------------------------------------

   CREATE SEQUENCE  "C##1DAMSANTAMARIA"."SEQ_IDCONTENIDO"  MINVALUE 1 MAXVALUE 9999999999999999999999999999 INCREMENT BY 1 START WITH 61 CACHE 20 NOORDER  NOCYCLE  NOKEEP  NOSCALE  GLOBAL ;
