--------------------------------------------------------
--  DDL for Function ELIMINAR_SERIE
--------------------------------------------------------

  CREATE OR REPLACE EDITIONABLE FUNCTION "C##1DAMSANTAMARIA"."ELIMINAR_SERIE" (
    p_id_serie IN NUMBER
) RETURN NUMBER
IS
    v_filas_eliminadas NUMBER := 0;
BEGIN
    -- Eliminar los artículos facturados asociados a las líneas de factura de los capítulos de la serie
    DELETE FROM Articulos_Facturar
    WHERE ID_LINEA IN (
        SELECT lf.ID 
        FROM Linea_Factura lf
        JOIN Capitulo c ON lf.ID_CARRO = c.ID_CONT
        WHERE c.ID_SERIE = p_id_serie
    );

    -- Eliminar las líneas de factura asociadas a los capítulos de la serie
    DELETE FROM Linea_Factura
    WHERE ID_CARRO IN (
        SELECT ID_CONT 
        FROM Capitulo
        WHERE ID_SERIE = p_id_serie
    );

    -- Eliminar los capítulos de la serie
    DELETE FROM Capitulo
    WHERE ID_SERIE = p_id_serie;

    -- Eliminar la serie
    DELETE FROM Serie
    WHERE ID = p_id_serie;

    v_filas_eliminadas := SQL%ROWCOUNT;

    RETURN v_filas_eliminadas;
END;

/
