--------------------------------------------------------
--  DDL for Trigger ADMINISTRAR_USUARIO
--------------------------------------------------------

  CREATE OR REPLACE EDITIONABLE TRIGGER "C##1DAMSANTAMARIA"."ADMINISTRAR_USUARIO" 
AFTER INSERT OR DELETE ON Usuario
FOR EACH ROW
BEGIN
    IF INSERTING THEN
        -- Crear un carrito de compra para el nuevo usuario
        INSERT INTO Carro_Compra (ID, CHANGEDTS, ID_USUARIO)
        VALUES (SEQ_CARRO_COMPRAID.NEXTVAL, SYSDATE, :NEW.TAG_USUARIO);

        -- Crear una factura preestablecida para el nuevo usuario
        INSERT INTO Factura (NUMERO, FECHA, IMP_BASE, IMP_IVA, CHANGEDTS, ID_USUARIO)
        VALUES (SEC_FACTURAID.NEXTVAL, SYSDATE, 0, 0, SYSDATE, :NEW.TAG_USUARIO);

    ELSIF DELETING THEN
        -- Eliminar los artículos facturados asociados a las líneas de la factura del usuario
        DELETE FROM Articulos_Facturar
        WHERE ID_LINEA IN (
            SELECT ID FROM Linea_Factura
            WHERE NUM_FACTURA IN (
                SELECT NUMERO FROM Factura WHERE ID_USUARIO = :OLD.TAG_USUARIO
            )
        );

        -- Eliminar las líneas de factura asociadas a las facturas del usuario
        DELETE FROM Linea_Factura
        WHERE NUM_FACTURA IN (
            SELECT NUMERO FROM Factura WHERE ID_USUARIO = :OLD.TAG_USUARIO
        );

        -- Eliminar las facturas asociadas al usuario eliminado
        DELETE FROM Factura
        WHERE ID_USUARIO = :OLD.TAG_USUARIO;

        -- Eliminar el carrito de compra asociado al usuario eliminado
        DELETE FROM Carro_Compra
        WHERE ID_USUARIO = :OLD.TAG_USUARIO;
    END IF;
END;

/
ALTER TRIGGER "C##1DAMSANTAMARIA"."ADMINISTRAR_USUARIO" ENABLE;
