--------------------------------------------------------
--  DDL for Sequence SEQ_CARRO_COMPRAID
--------------------------------------------------------

   CREATE SEQUENCE  "C##1DAMSANTAMARIA"."SEQ_CARRO_COMPRAID"  MINVALUE 1 MAXVALUE 9999999999999999999999999999 INCREMENT BY 1 START WITH 61 CACHE 20 NOORDER  NOCYCLE  NOKEEP  NOSCALE  GLOBAL ;
