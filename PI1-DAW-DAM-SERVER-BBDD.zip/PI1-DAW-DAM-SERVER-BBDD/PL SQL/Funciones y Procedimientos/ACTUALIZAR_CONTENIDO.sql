--------------------------------------------------------
--  DDL for Function ACTUALIZAR_CONTENIDO
--------------------------------------------------------

  CREATE OR REPLACE EDITIONABLE FUNCTION "C##1DAMSANTAMARIA"."ACTUALIZAR_CONTENIDO" (
    p_id IN CONTENIDO.ID%TYPE,
    p_titulo IN CONTENIDO.TITULO%TYPE DEFAULT NULL,
    p_descripcion IN CONTENIDO.DESCRIPCION%TYPE DEFAULT NULL,
    p_url_imagen IN CONTENIDO.URL_IMAGEN%TYPE DEFAULT NULL,
    p_actores IN CONTENIDO.ACTORES%TYPE DEFAULT NULL,
    p_punt_media IN CONTENIDO.PUNT_MEDIA%TYPE DEFAULT NULL,
    p_fech_estreno IN CONTENIDO.FECH_ESTRENO%TYPE DEFAULT NULL,
    p_duracion IN CONTENIDO.DURACION%TYPE DEFAULT NULL,
    p_director IN CONTENIDO.DIRECTOR%TYPE DEFAULT NULL,
    p_id_genero IN CONTENIDO.ID_GENERO%TYPE DEFAULT NULL,
    p_id_tarifa IN CONTENIDO.ID_TARIFA%TYPE DEFAULT NULL
) RETURN NUMBER
IS
    v_filas_actualizadas NUMBER := 0;
BEGIN
    UPDATE CONTENIDO
    SET 
        TITULO = NVL(p_titulo, TITULO),
        DESCRIPCION = NVL(p_descripcion, DESCRIPCION),
        URL_IMAGEN = NVL(p_url_imagen, URL_IMAGEN),
        ACTORES = NVL(p_actores, ACTORES),
        PUNT_MEDIA = NVL(p_punt_media, PUNT_MEDIA),
        FECH_ESTRENO = NVL(p_fech_estreno, FECH_ESTRENO),
        DURACION = NVL(p_duracion, DURACION),
        DIRECTOR = NVL(p_director, DIRECTOR),
        ID_GENERO = NVL(p_id_genero, ID_GENERO),
        ID_TARIFA = NVL(p_id_tarifa, ID_TARIFA),
        changedts = SYSDATE
    WHERE ID = p_id;

    v_filas_actualizadas := SQL%ROWCOUNT;

    RETURN v_filas_actualizadas;
END;

/
