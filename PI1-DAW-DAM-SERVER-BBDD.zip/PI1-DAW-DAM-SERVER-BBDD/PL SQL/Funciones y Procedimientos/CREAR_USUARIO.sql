--------------------------------------------------------
--  DDL for Procedure CREAR_USUARIO
--------------------------------------------------------
set define off;

  CREATE OR REPLACE EDITIONABLE PROCEDURE "C##1DAMSANTAMARIA"."CREAR_USUARIO" (
    p_tag_usuario IN VARCHAR2,
    usuarioContrasenya IN VARCHAR2,
    usuarioDomicilio IN VARCHAR2 DEFAULT NULL,
    usuarioCodPostal IN NUMBER DEFAULT NULL,
    usuarioEmail IN VARCHAR2 DEFAULT NULL,
    usuarioFechNac IN DATE DEFAULT NULL,
    usuarioNombre IN VARCHAR2,
    usuarioApellidos IN VARCHAR2,
    usuarioNumTarjeta IN NUMBER DEFAULT NULL
) IS
    existeUsuario NUMBER := 0;
BEGIN
    -- Check if the user already exists
    SELECT COUNT(*) INTO existeUsuario FROM Usuario WHERE TAG_USUARIO = p_tag_usuario;

    IF existeUsuario = 0 THEN
        -- Insert new user with specified TAG_USUARIO
        INSERT INTO Usuario (
            TAG_USUARIO, 
            CONTRASENYA, 
            DOMICILIO, 
            COD_POSTAL, 
            EMAIL, 
            FECH_NAC, 
            NOMBRE, 
            APELLIDOS, 
            NUM_TARJETA
        ) VALUES (
            p_tag_usuario, 
            usuarioContrasenya, 
            usuarioDomicilio, 
            usuarioCodPostal, 
            usuarioEmail, 
            usuarioFechNac, 
            usuarioNombre, 
            usuarioApellidos, 
            usuarioNumTarjeta
        );
    ELSE
        -- Raise an error if the user already exists
        RAISE_APPLICATION_ERROR(-20001, 'Ya existe ese usuario.');
    END IF;
EXCEPTION
    WHEN OTHERS THEN
        ROLLBACK;
        RAISE;
END;

/
