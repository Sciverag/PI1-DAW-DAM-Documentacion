package es.ieslavereda.base;

/**
 * Clase que contiene la URL base de la API.
 */
public class Parameters {
    public final static String URL = "http://172.30.198.205:8080/";
}
