--------------------------------------------------------
--  DDL for Function ELIMINAR_CONTENIDO
--------------------------------------------------------

  CREATE OR REPLACE EDITIONABLE FUNCTION "C##1DAMSANTAMARIA"."ELIMINAR_CONTENIDO" (
    p_id IN contenido.id%TYPE,
    p_tipo_contenido IN VARCHAR2 -- 'Pelicula', 'Corto', 'Capitulo'
) RETURN NUMBER
IS
    v_existe_contenido NUMBER := 0;
    v_filas_eliminadas NUMBER := 0;
BEGIN
    -- Verificar si el contenido existe
    SELECT COUNT(*)
    INTO v_existe_contenido
    FROM contenido
    WHERE id = p_id;

    IF v_existe_contenido <> 1 THEN
        RAISE_APPLICATION_ERROR(-20001, 'Contenido no encontrado');
    END IF;
    
    -- Eliminar artículos facturados asociados al contenido
    DELETE FROM Articulos_Facturar WHERE ID_CONTENIDO = p_id;

    -- Eliminar líneas de factura asociadas al contenido
    DELETE FROM Linea_Factura WHERE ID IN (
        SELECT lf.ID
        FROM Linea_Factura lf
        JOIN Articulos_Facturar af ON lf.ID = af.ID_LINEA
        WHERE af.ID_CONTENIDO = p_id
    );

    -- Eliminar el tipo específico de contenido
    IF p_tipo_contenido = 'Pelicula' THEN
        DELETE FROM Pelicula WHERE ID_CONT = p_id;
    ELSIF p_tipo_contenido = 'Corto' THEN
        DELETE FROM Corto WHERE ID_CONT = p_id;
    ELSIF p_tipo_contenido = 'Capitulo' THEN
        DELETE FROM Capitulo WHERE ID_CONT = p_id;
    ELSE
        RAISE_APPLICATION_ERROR(-20002, 'Tipo de contenido no válido');
    END IF;
    
    DELETE FROM ALQUILA WHERE ID_CONTENIDO = p_id;

    -- Eliminar el contenido de la tabla Contenido
    DELETE FROM Contenido WHERE ID = p_id;

    -- Contar las filas eliminadas
    v_filas_eliminadas := SQL%ROWCOUNT;

    RETURN v_filas_eliminadas;
END;

/
